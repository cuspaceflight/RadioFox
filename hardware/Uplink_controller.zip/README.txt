1. Name: Iain Waugh

2. Company: Cambridge University Spaceflight

3. Billing address: Fairways, Folders Lane, Burgess Hill, West Sussex, RH15 0DX, United Kingdom

4. Shipping address: FAO Ed Moore, Churchill College, Storey's Way, Cambridge, CB3 0DS, United Kingdom

5. Shipping option: FEDEX

6. Order: DSS 1 piece (3 boards on one DSS piece).

7. For all orders from Europe Union: NO VAT ID

8. Payment option: Visa

9. De-panelization with smooth borders (abrasive disk)

10. Notes: Additional silkscreen needed for bottom layer. Silkscreens are eagle defaults
      layers tPlace and bPlace (21 and 22).
      Would like it to be done on the 10mils order time please.